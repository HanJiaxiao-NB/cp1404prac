# What did you see on line 1?
# I see 5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20.
# What was the smallest number you could have seen, what was the largest?
# The smallest number is 5 and the largest number is 20.

# What did you see on line 2?
# I see 3,5,7,9.
# What was the smallest number you could have seen, what was the largest?
# The smallest number is 3 and the largest number is 9.
# Could line 2 have produced a 4?
# No.

# What did you see on line 3?
# I see all of the number >=2.5 but <5.5.
# What was the smallest number you could have seen, what was the largest?
# The smallest number is 5.382650204811771 and the largest number is 2.515398394955882.

import randem
print(random.randint(1, 101))
